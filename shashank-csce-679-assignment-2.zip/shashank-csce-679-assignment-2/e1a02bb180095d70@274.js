import define1 from "./a2e58f97fd5e8d7c@756.js";

function _1(md){return(
md`# CSCE 679 Assignment 2 UIN: 534002338 Shashank Jagtap`
)}

function _data(FileAttachment){return(
FileAttachment("temperature_daily.csv").csv()
)}

function _4(Inputs,data){return(
Inputs.table(data, { columns: Object.keys(data[0]) })
)}

function _radios(Inputs){return(
Inputs.radio(["MAX", "MIN"], {label: "Temperature", value: "MAX"})
)}

function _6(data,radios,d3,DOM)
{// Define the months array for converting numerical months to names
const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

// Extract unique years from the dataset by mapping each data point to its year, creating a Set to remove duplicates, then converting back to an array
const uniqueYears = Array.from(new Set(data.map(d => d.date.split('-')[0])));

// Extract unique months similarly
const uniqueMonths = Array.from(new Set(data.map(d => d.date.split('-')[1])));

// Create empty objects to store the maximum and minimum temperatures for each year-month combination
const max_temperatureByYearMonth = {};
const min_temperatureByYearMonth = {};

// Get the radio button selection (max or min temperature view)
const toggle = radios;

// Calculate global temperature ranges to establish consistent color scaling
// Extract all valid max temperatures as numbers from the dataset
const allmaxTemps = data.map(d => +d.max_temperature).filter(t => !isNaN(t));
// Extract all valid min temperatures as numbers
const allminTemps = data.map(d => +d.min_temperature).filter(t => !isNaN(t));
// Find the lowest minimum temperature across the entire dataset
const globalMinTemp = d3.min(allminTemps);
// Find the highest maximum temperature across the entire dataset
const globalMaxTemp = d3.max(allmaxTemps);

// Process each data point to populate our year-month temperature objects
data.forEach(d => {
  // Split the date string to get year, month components
  const year = d.date.split('-')[0];
  const month = d.date.split('-')[1];
  // Convert string temperatures to numbers
  const max_temperature = +d.max_temperature;
  const min_temperature = +d.min_temperature;
  
  // Initialize the nested structure if it doesn't exist yet for maximum temperatures
  if (!max_temperatureByYearMonth[year]) {
    max_temperatureByYearMonth[year] = {};
  }
  if (!max_temperatureByYearMonth[year][month]) {
    max_temperatureByYearMonth[year][month] = -Infinity; // Start with lowest possible value for max tracking
  }
  
  // Update the max temperature if the current value is higher
  if (max_temperature > max_temperatureByYearMonth[year][month]) {
    max_temperatureByYearMonth[year][month] = max_temperature;
  }
  
  // Same initialization for minimum temperatures
  if (!min_temperatureByYearMonth[year]) {
    min_temperatureByYearMonth[year] = {};
  }
  if (!min_temperatureByYearMonth[year][month]) {
    min_temperatureByYearMonth[year][month] = Infinity; // Start with highest possible value for min tracking
  }
  
  // Update the min temperature if the current value is lower
  if (min_temperature < min_temperatureByYearMonth[year][month]) {
    min_temperatureByYearMonth[year][month] = min_temperature;
  }
});

// Create a color scale for temperature visualization with appropriate breakpoints
// Uses a gradient from light yellow to red for temperature ranges
const temperatureScale = d3.scaleLinear()
  .domain([0, 10, 20, 30, 40]) // Temperature breakpoints in Celsius
  .range(["#fff5e6", "#ffff00", "#ffcc00", "#ff6600", "#ff0000"]); // Corresponding colors

// Set dimensions for the visualization
const height = 500;
const width = 1152;
const margin = { left: 60, top: 60, right: 60, bottom: 60 }; // Margins for axes and labels

// Create the SVG element using Observable's DOM utility
const svg = d3.select(DOM.svg(width, height));

// Create x-scale for years (categorical bands)
const xScale = d3.scaleBand()
  .domain(uniqueYears) // Use all years as categories
  .range([margin.left, width - margin.right - 60]) // Map to horizontal space
  .padding(0.1); // Add padding between year columns

// Create y-scale for months (categorical bands)
const yScale = d3.scaleBand()
  .domain(uniqueMonths) // Use all months as categories
  .range([margin.top, height - margin.bottom]) // Map to vertical space
  .padding(0.1); // Add padding between month rows

// Create scale for the temperature legend
const legendScale = d3.scaleLinear()
  .domain([0, 40]) // Match the temperature scale range
  .range([0, 200]); // Height of the legend in pixels

// Create a group element for the legend positioned to the right of the heatmap
const legendGroup = svg.append("g")
  .attr("transform", `translate(${width - margin.right - 40}, ${margin.top})`);

// Create a gradient definition for the legend's color visualization
const gradient = svg.append("defs")
  .append("linearGradient")
  .attr("id", "gradient")
  .attr("x1", "0%")
  .attr("x2", "0%")
  .attr("y1", "0%")
  .attr("y2", "100%"); // Vertical gradient

// Create a tooltip element for displaying information on hover
const tooltip = d3.select("body").append("div")
  .attr("class", "tooltip")
  .style("position", "absolute")
  .style("visibility", "hidden")
  .style("background-color", "rgba(0, 0, 0, 0.7)")
  .style("color", "#fff")
  .style("padding", "10px")
  .style("border-radius", "5px")
  .style("font-size", "12px");

// Generate cell groups for each year-month combination
const cells = svg.selectAll("g.cell")
  // Create a flattened array of all year-month combinations
  .data(uniqueYears.flatMap(year => uniqueMonths.map(month => ({ year, month }))))
  .enter()
  .append("g")
  .attr("class", "cell")
  .attr("transform", d => `translate(${xScale(d.year)}, ${yScale(d.month)})`); // Position each cell

// Add rectangles to each cell representing the temperature
cells.append("rect")
  .attr("width", xScale.bandwidth())
  .attr("height", yScale.bandwidth())
  .attr("stroke", "#ccc") // Light gray border
  .attr("fill", d => {
    // Color based on toggle selection (max or min temperature)
    if (toggle === "MAX") {
      const maxTemp = max_temperatureByYearMonth[d.year]?.[d.month];
      return maxTemp !== undefined ? temperatureScale(maxTemp) : "#ffffff"; // White if no data
    } else { // "MIN" toggle
      const minTemp = min_temperatureByYearMonth[d.year]?.[d.month];
      return minTemp !== undefined ? temperatureScale(minTemp) : "#ffffff"; // White if no data
    }
  })
  // Add mouseover event to show tooltip
  .on("mouseover", function(event, d) {
    const year = d.year;
    const month = d.month;
    const max_temp = max_temperatureByYearMonth[year]?.[month];
    const min_temp = min_temperatureByYearMonth[year]?.[month];
    
    // Set tooltip content based on toggle selection
    if(toggle === 'MAX'){
      tooltip.html(`
        <strong>Date:</strong> ${months[+month - 1]} ${year}<br>
        <strong>Maximum Temp:</strong> ${max_temp !== undefined ? max_temp + '°C' : 'N/A'}
      `)
      .style("visibility", "visible");
    } else {
      tooltip.html(`
        <strong>Date:</strong> ${months[+month - 1]} ${year}<br>
        <strong>Minimum Temp:</strong> ${min_temp !== undefined ? min_temp + '°C' : 'N/A'}
      `)
      .style("visibility", "visible");
    }
  })
  // Update tooltip position as mouse moves
  .on("mousemove", function(event) {
    tooltip.style("top", (event.pageY + 10) + "px")
      .style("left", (event.pageX + 10) + "px");
  })
  // Hide tooltip when mouse leaves
  .on("mouseout", function() {
    tooltip.style("visibility", "hidden");
  });

// Add x-axis at the top showing years
svg.append('g')
  .attr('transform', `translate(0, ${margin.top})`)
  .call(d3.axisTop(xScale));

// Add y-axis at the left showing months
svg.append('g')
  .attr('transform', `translate(${margin.left}, 0)`)
  .call(d3.axisLeft(yScale).tickFormat(d => months[+d - 1])); // Convert month numbers to names

// Define color stops for the gradient used in the legend
// This creates a smooth transition through the temperature color ranges
gradient.append("stop")
  .attr("offset", "0%")
  .attr("stop-color", "#fff5e6"); // Light yellow for 0–10°C
gradient.append("stop")
  .attr("offset", "25%")
  .attr("stop-color", "#ffff00"); // Yellow for 10–20°C
gradient.append("stop")
  .attr("offset", "50%")
  .attr("stop-color", "#ffcc00"); // Orange for 20–30°C
gradient.append("stop")
  .attr("offset", "75%")
  .attr("stop-color", "#ff6600"); // Red-orange for 30–40°C
gradient.append("stop")
  .attr("offset", "100%")
  .attr("stop-color", "#ff0000"); // Red for 40°C

// Create a colored rectangle for the legend
legendGroup.append("rect")
  .attr("x", 0)
  .attr("y", 0)
  .attr("width", 20) // Width of the legend bar
  .attr("height", 200) // Height of the legend bar
  .style("fill", "url(#gradient)"); // Apply the color gradient

// Add temperature scale to the legend
legendGroup.append("g")
  .attr("transform", "translate(25, 0)") // Position to the right of the color bar
  .call(d3.axisRight(legendScale)
    .ticks(5) // Show 5 temperature points
    .tickFormat(d => `${d}°C`)); // Format with degree symbol

// Add a title to the heatmap that changes based on toggle selection
svg.append("text")
  .attr("x", width / 2)
  .attr("y", margin.top / 2)
  .attr("text-anchor", "middle")
  .style("font-size", "16px")
  .style("font-weight", "bold")
  .text(toggle === "MAX" ? "Maximum Monthly Temperatures" : "Minimum Monthly Temperatures");

// Return the completed SVG for Observable to display
return svg.node();}


function _radios1(Inputs){return(
Inputs.radio(["MAX", "MIN"], {label: "Temperature", value: "MAX"})
)}

function _8(data,radios1,d3,DOM)
{// Define the months array (from January to December)
const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

// Extract unique years and months from the data
const uniqueYears = Array.from(new Set(data.map(d => d.date.split('-')[0])));
const lastYears = uniqueYears.slice(-10); // Take only the last 10 years for display
const uniqueMonths = Array.from(new Set(data.map(d => d.date.split('-')[1])));

// Initialize objects to store maximum and minimum temperatures by year and month
const max_temperatureByYearMonth = {};
const min_temperatureByYearMonth = {};

// Get the selected display mode from the radio button (MAX or MIN temperature)
const toggle = radios1;

// Calculate global min/max temperatures across the entire dataset for scaling
const allmaxTemps = data.map(d => +d.max_temperature).filter(t => !isNaN(t));
const allminTemps = data.map(d => +d.min_temperature).filter(t => !isNaN(t));
const globalMinTemp = d3.min(allminTemps);
const globalMaxTemp = d3.max(allmaxTemps);

// Create a data structure to store daily temperature data for the line charts
const dailyTempsByYearMonth = {};

// Process each data point to organize by year, month, and day
data.forEach(d => {
  // Parse date components
  const year = d.date.split('-')[0];  
  const month = d.date.split('-')[1]; 
  const day = +d.date.split('-')[2]; // Convert day to number
  
  // Convert temperature strings to numbers
  const max_temperature = +d.max_temperature;  
  const min_temperature = +d.min_temperature;  
  
  // Initialize nested objects for max temperatures if they don't exist
  if (!max_temperatureByYearMonth[year]) {
    max_temperatureByYearMonth[year] = {};
  }
  if (!max_temperatureByYearMonth[year][month]) {
    max_temperatureByYearMonth[year][month] = -Infinity; // Start with lowest possible value
  }
  
  // Update maximum temperature if current value is higher
  if (max_temperature > max_temperatureByYearMonth[year][month]) {
    max_temperatureByYearMonth[year][month] = max_temperature;
  }
  
  // Similar initialization for minimum temperatures
  if (!min_temperatureByYearMonth[year]) {
    min_temperatureByYearMonth[year] = {};
  }
  if (!min_temperatureByYearMonth[year][month]) {
    min_temperatureByYearMonth[year][month] = Infinity; // Start with highest possible value
  }
  
  // Update minimum temperature if current value is lower
  if (min_temperature < min_temperatureByYearMonth[year][month]) {
    min_temperatureByYearMonth[year][month] = min_temperature;
  }
  
  // Store daily temperature data for creating line charts
  if (!dailyTempsByYearMonth[year]) {
    dailyTempsByYearMonth[year] = {};
  }
  if (!dailyTempsByYearMonth[year][month]) {
    dailyTempsByYearMonth[year][month] = [];
  }
  
  // Add this day's data to the appropriate year/month array
  dailyTempsByYearMonth[year][month].push({
    day,
    max_temperature,
    min_temperature
  });
});

// Create a color scale for temperature ranges
// Maps temperature values to colors: cooler temps = lighter colors, hotter = darker/redder
const temperatureScale = d3.scaleLinear()
  .domain([0, 10, 20, 30, 40]) // Temperature breakpoints in Celsius
  .range(["#fff5e6", "#ffff00", "#ffcc00", "#ff6600", "#ff0000"]); // Light yellow to red gradient
  
// Define visualization dimensions
const height = 800;
const width = 1152;
const margin = { left: 60, top: 60, right: 60, bottom: 60 };

// Create the main SVG container
const svg = d3.select(DOM.svg(width, height));

// Create x-scale for years (categorical bands)
const xScale = d3.scaleBand()
  .domain(lastYears) // Years as domain
  .range([margin.left, width - margin.right - 60])
  .padding(0.1); // Add spacing between year bands

// Create y-scale for months (categorical bands)
const yScale = d3.scaleBand()
  .domain(uniqueMonths) // Months as domain
  .range([margin.top, height - margin.bottom])
  .padding(0.1); // Add spacing between month bands

// Define scales for the mini line charts inside each cell
const xMini = d3.scaleLinear().domain([1, 31]).range([2, xScale.bandwidth() - 2]); // Days 1-31
const yMini = d3.scaleLinear().domain([globalMinTemp, globalMaxTemp]).range([yScale.bandwidth() - 2, 2]); // Temperature range

// Create scale for the temperature legend
const legendScale = d3.scaleLinear()
  .domain([0, 40]) // Temperature range matching the color scale
  .range([0, 200]); // 200px height for the legend

// Create a group for the legend
const legendGroup = svg.append("g")
  .attr("transform", `translate(${width - margin.right - 50}, ${margin.top})`); // Position to the right

// Create a linear gradient for the color legend
const gradient = svg.append("defs")
  .append("linearGradient")
  .attr("id", "gradient")
  .attr("x1", "0%")
  .attr("x2", "0%")
  .attr("y1", "0%")
  .attr("y2", "100%");

// Create a tooltip element for hover information
const tooltip = d3.select("body").append("div")
  .attr("class", "tooltip")
  .style("position", "absolute")
  .style("visibility", "hidden")
  .style("background-color", "rgba(0, 0, 0, 0.7)")
  .style("color", "#fff")
  .style("padding", "10px")
  .style("border-radius", "5px")
  .style("font-size", "12px");

// Create cell groups for each year-month combination
const cells = svg.selectAll("g.cell")
  .data(lastYears.flatMap(year => uniqueMonths.map(month => ({ year, month })))) // Create data array with all combinations
  .enter()
  .append("g")
  .attr("class", "cell")
  .attr("transform", d => `translate(${xScale(d.year)}, ${yScale(d.month)})`); // Position each cell

// Draw rectangles for each cell in the heatmap
cells.append("rect")
  .attr("width", xScale.bandwidth())
  .attr("height", yScale.bandwidth())
  .attr("stroke", "#ccc") // Cell border
  .attr("fill", d => {
    // Color based on selected temperature mode (MAX or MIN)
    if (toggle === "MAX") {
      const maxTemp = max_temperatureByYearMonth[d.year]?.[d.month];
      return maxTemp !== undefined ? temperatureScale(maxTemp) : "#ffffff"; // White if no data
    } else { // "MIN"
      const minTemp = min_temperatureByYearMonth[d.year]?.[d.month];
      return minTemp !== undefined ? temperatureScale(minTemp) : "#ffffff"; // White if no data
    }
  })
  // Add tooltip interactions
  .on("mouseover", function(event, d) {
    // Show tooltip with relevant information
    const year = d.year;
    const month = d.month;
    const max_temp = max_temperatureByYearMonth[year]?.[month];
    const min_temp = min_temperatureByYearMonth[year]?.[month];
    
    if(toggle === 'MAX'){
      // Show max temperature info
      tooltip.html(`
        <strong>Date:</strong> ${months[+month - 1]} ${year}<br>
        <strong>Maximum Temp:</strong> ${max_temp !== undefined ? max_temp + '°C' : 'N/A'}
      `)
      .style("visibility", "visible");
    } else {
      // Show min temperature info
      tooltip.html(`
        <strong>Date:</strong> ${months[+month - 1]} ${year}<br>
        <strong>Minimum Temp:</strong> ${min_temp !== undefined ? min_temp + '°C' : 'N/A'}
      `)
      .style("visibility", "visible");
    }
  })
  .on("mousemove", function(event) {
    // Position the tooltip near the mouse cursor
    tooltip.style("top", (event.pageY + 10) + "px")
      .style("left", (event.pageX + 10) + "px");
  })
  .on("mouseout", function() {
    // Hide the tooltip when mouse leaves
    tooltip.style("visibility", "hidden");
  });

// Add mini line charts inside each cell to show daily temperature trends
cells.each(function(d) {
  const cellGroup = d3.select(this);
  const tempData = dailyTempsByYearMonth[d.year]?.[d.month] || [];
  
  if (tempData.length > 0) {
    // Create a small SVG for the mini chart
    const miniSvg = cellGroup.append("svg")
      .attr("width", xScale.bandwidth())
      .attr("height", yScale.bandwidth());
    
    // Define line generator for max temperatures
    const maxLine = d3.line()
      .x(d => xMini(d.day)) // Map day to x position
      .y(d => yMini(d.max_temperature)) // Map max temp to y position
      .curve(d3.curveMonotoneX); // Smooth curve
    
    // Define line generator for min temperatures
    const minLine = d3.line()
      .x(d => xMini(d.day)) // Map day to x position
      .y(d => yMini(d.min_temperature)) // Map min temp to y position
      .curve(d3.curveMonotoneX); // Smooth curve
    
    // Draw the max temperature line (green)
    miniSvg.append("path")
      .datum(tempData) // Use the daily data
      .attr("fill", "none")
      .attr("stroke", "green")
      .attr("stroke-width", 2)
      .attr("d", maxLine); // Generate the path
    
    // Draw the min temperature line (blue)
    miniSvg.append("path")
      .datum(tempData) // Use the daily data
      .attr("fill", "none")
      .attr("stroke", "blue")
      .attr("stroke-width", 2)
      .attr("d", minLine); // Generate the path
  }
});

// Add axis for years at the top of the chart
svg.append('g')
  .attr('transform', `translate(0, ${margin.top})`) // Position at the top
  .call(d3.axisTop(xScale));

// Add axis for months on the left side
svg.append('g')
  .attr('transform', `translate(${margin.left}, 0)`) // Position on the left
  .call(d3.axisLeft(yScale).tickFormat(d => months[+d - 1])); // Convert month numbers to names

// Add color stops to the gradient for the legend
gradient.append("stop")
  .attr("offset", "0%")
  .attr("stop-color", "#fff5e6"); // Light yellow for 0–10°C
gradient.append("stop")
  .attr("offset", "25%")
  .attr("stop-color", "#ffff00"); // Yellow for 10–20°C
gradient.append("stop")
  .attr("offset", "50%")
  .attr("stop-color", "#ffcc00"); // Orange for 20–30°C
gradient.append("stop")
  .attr("offset", "75%")
  .attr("stop-color", "#ff6600"); // Red-orange for 30–40°C
gradient.append("stop")
  .attr("offset", "100%")
  .attr("stop-color", "#ff0000"); // Red for 40°C+

// Create the color scale rectangle for the legend
legendGroup.append("rect")
  .attr("x", 0)
  .attr("y", 0)
  .attr("width", 20) // Width of the color bar
  .attr("height", 200) // Height of the color bar
  .style("fill", "url(#gradient)"); // Apply the gradient fill

// Add axis to the legend to show temperature values
legendGroup.append("g")
  .attr("transform", "translate(25, 0)") // Position to the right of the color bar
  .call(d3.axisRight(legendScale)
    .ticks(5) // Show 5 tick marks
    .tickFormat(d => `${d}°C`)); // Format as temperature

// Add a legend for the mini line charts
const miniChartLegendGroup = svg.append("g")
  .attr("transform", `translate(${width - margin.right - 50}, ${margin.top + 250})`); // Position below temperature legend

// Add title for the mini chart legend
miniChartLegendGroup.append("text")
  .attr("x", 0)
  .attr("y", -10)
  .attr("text-anchor", "start")
  .style("font-size", "12px")
  .style("font-weight", "bold")
  .text("Temperature Lines");

// Add max temperature line example in the legend
miniChartLegendGroup.append("line")
  .attr("x1", 0)
  .attr("y1", 10)
  .attr("x2", 20)
  .attr("y2", 10)
  .attr("stroke", "green")
  .attr("stroke-width", 5);
miniChartLegendGroup.append("text")
  .attr("x", 25)
  .attr("y", 14)
  .attr("text-anchor", "start")
  .style("font-size", "12px")
  .text("Max Temp");

// Add min temperature line example in the legend
miniChartLegendGroup.append("line")
  .attr("x1", 0)
  .attr("y1", 30)
  .attr("x2", 20)
  .attr("y2", 30)
  .attr("stroke", "blue")
  .attr("stroke-width", 5);
miniChartLegendGroup.append("text")
  .attr("x", 25)
  .attr("y", 34)
  .attr("text-anchor", "start")
  .style("font-size", "12px")
  .text("Min Temp");

// Add title for the entire heatmap
svg.append("text")
  .attr("x", width / 2)
  .attr("y", margin.top / 2)
  .attr("text-anchor", "middle")
  .style("font-size", "16px")
  .style("font-weight", "bold")
  .text(toggle === "MAX" ? "Maximum Monthly Temperatures (2008 - 2017)" : "Minimum Monthly Temperatures (2008 - 2017)");

// Return the SVG node to be displayed by Observable
return svg.node();}


export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["temperature_daily.csv", {url: new URL("./files/b14b4f364b839e451743331d515692dfc66046924d40e4bff6502f032bd591975811b46cb81d1e7e540231b79a2fa0f4299b0e339e0358f08bef900595e74b15.csv", import.meta.url), mimeType: "text/csv", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("data")).define("data", ["FileAttachment"], _data);
  const child1 = runtime.module(define1);
  main.import("Inputs", child1);
  main.variable(observer()).define(["Inputs","data"], _4);
  main.variable(observer("viewof radios")).define("viewof radios", ["Inputs"], _radios);
  main.variable(observer("radios")).define("radios", ["Generators", "viewof radios"], (G, _) => G.input(_));
  main.variable(observer()).define(["data","radios","d3","DOM"], _6);
  main.variable(observer("viewof radios1")).define("viewof radios1", ["Inputs"], _radios1);
  main.variable(observer("radios1")).define("radios1", ["Generators", "viewof radios1"], (G, _) => G.input(_));
  main.variable(observer()).define(["data","radios1","d3","DOM"], _8);
  return main;
}
